def main():
	x=0
	x=5
	x=x * x
	return x

# Boilerplat
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)

