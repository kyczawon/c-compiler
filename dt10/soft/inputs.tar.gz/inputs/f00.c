int main()
{
    return 10;
}

